import express from 'express';
import { createPrice } from '../controllers/priceController.js';
import { createPromotionDefinition, createPromotionApplication} from '../controllers/promotionController.js'
import { getFinalPrice } from '../controllers/consultasController.js'
const router = express.Router();

router.get('/', (req, res) => {
    res.json({ message: 'API de eventos de Walletfy, version 1.0.0' });
});

router.post('/createPrice', createPrice);
router.post('/promotions/definitions', createPromotionDefinition);
router.post('/promotions/applications',createPromotionApplication);
router.post('/queries/final-price', getFinalPrice);
export default router;
