export const RoutePaths = {
  HOME: '/',
  PRICING: '/pricing',
};
